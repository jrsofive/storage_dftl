/*
 * PalmOne's (TM) PDAs.
 *
 * Copyright (C) 2006-2007 Andrzej Zaborowski  <balrog@zabor.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 or
 * (at your option) version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see <http://www.gnu.org/licenses/>.
 */

#include "qemu/osdep.h"
#include "qapi/error.h"
#include "audio/audio.h"
#include "sysemu/sysemu.h"
#include "sysemu/qtest.h"
#include "ui/console.h"
#include "hw/arm/omap.h"
#include "hw/boards.h"
#include "hw/arm/boot.h"
#include "hw/input/tsc2xxx.h"
#include "hw/irq.h"
#include "hw/loader.h"
#include "cpu.h"
#include "qemu/cutils.h"
#include "qom/object.h"
#include "qemu/error-report.h"


static uint64_t static_read(void *opaque, hwaddr offset, unsigned size)
{
    uint32_t *val = (uint32_t *)opaque;
    uint32_t sizemask = 7 >> size;

    return *val >> ((offset & sizemask) << 3);
}

static void static_write(void *opaque, hwaddr offset, uint64_t value,
                         unsigned size)
{
#ifdef SPY
    printf("%s: value %08lx written at " PA_FMT "\n",
                    __func__, value, offset);
#endif
}

static const MemoryRegionOps static_ops = {
    .read = static_read,
    .write = static_write,
    .valid.min_access_size = 1,
    .valid.max_access_size = 4,
    .endianness = DEVICE_NATIVE_ENDIAN,
};

/* Palm Tunsgten|E support */

/* Shared GPIOs */
#define PALMTE_USBDETECT_GPIO   0
#define PALMTE_USB_OR_DC_GPIO   1
#define PALMTE_TSC_GPIO                 4
#define PALMTE_PINTDAV_GPIO     6
#define PALMTE_MMC_WP_GPIO      8
#define PALMTE_MMC_POWER_GPIO   9
#define PALMTE_HDQ_GPIO                 11
#define PALMTE_HEADPHONES_GPIO  14
#define PALMTE_SPEAKER_GPIO     15
/* MPU private GPIOs */
#define PALMTE_DC_GPIO          2
#define PALMTE_MMC_SWITCH_GPIO  4
#define PALMTE_MMC1_GPIO        6
#define PALMTE_MMC2_GPIO        7
#define PALMTE_MMC3_GPIO        11

static MouseTransformInfo palmte_pointercal = {
    .x = 320,
    .y = 320,
    .a = { -5909, 8, 22465308, 104, 7644, -1219972, 65536 },
};

static void palmte_microwire_setup(struct omap_mpu_state_s *cpu)
{
    uWireSlave *tsc;

    tsc = tsc2102_init(qdev_get_gpio_in(cpu->gpio, PALMTE_PINTDAV_GPIO));

    omap_uwire_attach(cpu->microwire, tsc, 0);
    omap_mcbsp_i2s_attach(cpu->mcbsp1, tsc210x_codec(tsc));

    tsc210x_set_transform(tsc, &palmte_pointercal);
}

static struct {
    int row;
    int column;
} palmte_keymap[0x80] = {
    [0 ... 0x7f] = { -1, -1 },
    [0x3b] = { 0, 0 },  /* F1   -> Calendar */
    [0x3c] = { 1, 0 },  /* F2   -> Contacts */
    [0x3d] = { 2, 0 },  /* F3   -> Tasks List */
    [0x3e] = { 3, 0 },  /* F4   -> Note Pad */
    [0x01] = { 4, 0 },  /* Esc  -> Power */
    [0x4b] = { 0, 1 },  /*         Left */
    [0x50] = { 1, 1 },  /*         Down */
    [0x48] = { 2, 1 },  /*         Up */
    [0x4d] = { 3, 1 },  /*         Right */
    [0x4c] = { 4, 1 },  /*         Centre */
    [0x39] = { 4, 1 },  /* Spc  -> Centre */
};

static void palmte_button_event(void *opaque, int keycode)
{
    struct omap_mpu_state_s *cpu = opaque;

    if (palmte_keymap[keycode & 0x7f].row != -1)
        omap_mpuio_key(cpu->mpuio,
                        palmte_keymap[keycode & 0x7f].row,
                        palmte_keymap[keycode & 0x7f].column,
                        !(keycode & 0x80));
}

/*
 * Encapsulation of some GPIO line behaviour for the Palm board
 *
 * QEMU interface:
 *  + unnamed GPIO inputs 0..6: for the various miscellaneous input lines
 */

#define TYPE_PALM_MISC_GPIO "palm-misc-gpio"
OBJECT_DECLARE_SIMPLE_TYPE(PalmMiscGPIOState, PALM_MISC_GPIO)

struct PalmMiscGPIOState {
    SysBusDevice parent_obj;
};

static void palmte_onoff_gpios(void *opaque, int line, int level)
{
    switch (line) {
    case 0:
        printf("%s: current to MMC/SD card %sabled.\n",
                        __func__, level ? "dis" : "en");
        break;
    case 1:
        printf("%s: internal speaker amplifier %s.\n",
                        __func__, level ? "down" : "on");
        break;

    /* These LCD & Audio output signals have not been identified yet.  */
    case 2:
    case 3:
    case 4:
        printf("%s: LCD GPIO%i %s.\n",
                        __func__, line - 1, level ? "high" : "low");
        break;
    case 5:
    case 6:
        printf("%s: Audio GPIO%i %s.\n",
                        __func__, line - 4, level ? "high" : "low");
        break;
    }
}

static void palm_misc_gpio_init(Object *obj)
{
    DeviceState *dev = DEVICE(obj);

    qdev_init_gpio_in(dev, palmte_onoff_gpios, 7);
}

static const TypeInfo palm_misc_gpio_info = {
    .name = TYPE_PALM_MISC_GPIO,
    .parent = TYPE_SYS_BUS_DEVICE,
    .instance_size = sizeof(PalmMiscGPIOState),
    .instance_init = palm_misc_gpio_init,
    /*
     * No class init required: device has no internal state so does not
     * need to set up reset or vmstate, and has no realize method.
     */
};

static void palmte_gpio_setup(struct omap_mpu_state_s *cpu)
{
    DeviceState *misc_gpio;

    misc_gpio = sysbus_create_simple(TYPE_PALM_MISC_GPIO, -1, NULL);

    omap_mmc_handlers(cpu->mmc,
                    qdev_get_gpio_in(cpu->gpio, PALMTE_MMC_WP_GPIO),
                    qemu_irq_invert(omap_mpuio_in_get(cpu->mpuio)
                            [PALMTE_MMC_SWITCH_GPIO]));

    qdev_connect_gpio_out(cpu->gpio, PALMTE_MMC_POWER_GPIO,
                          qdev_get_gpio_in(misc_gpio, 0));
    qdev_connect_gpio_out(cpu->gpio, PALMTE_SPEAKER_GPIO,
                          qdev_get_gpio_in(misc_gpio, 1));
    qdev_connect_gpio_out(cpu->gpio, 11, qdev_get_gpio_in(misc_gpio, 2));
    qdev_connect_gpio_out(cpu->gpio, 12, qdev_get_gpio_in(misc_gpio, 3));
    qdev_connect_gpio_out(cpu->gpio, 13, qdev_get_gpio_in(misc_gpio, 4));
    omap_mpuio_out_set(cpu->mpuio, 1, qdev_get_gpio_in(misc_gpio, 5));
    omap_mpuio_out_set(cpu->mpuio, 3, qdev_get_gpio_in(misc_gpio, 6));

    /* Reset some inputs to initial state.  */
    qemu_irq_lower(qdev_get_gpio_in(cpu->gpio, PALMTE_USBDETECT_GPIO));
    qemu_irq_lower(qdev_get_gpio_in(cpu->gpio, PALMTE_USB_OR_DC_GPIO));
    qemu_irq_lower(qdev_get_gpio_in(cpu->gpio, 4));
    qemu_irq_lower(qdev_get_gpio_in(cpu->gpio, PALMTE_HEADPHONES_GPIO));
    qemu_irq_lower(omap_mpuio_in_get(cpu->mpuio)[PALMTE_DC_GPIO]);
    qemu_irq_raise(omap_mpuio_in_get(cpu->mpuio)[6]);
    qemu_irq_raise(omap_mpuio_in_get(cpu->mpuio)[7]);
    qemu_irq_raise(omap_mpuio_in_get(cpu->mpuio)[11]);
}

static struct arm_boot_info palmte_binfo = {
    .loader_start = OMAP_EMIFF_BASE,
    .ram_size = 0x02000000,
    .board_id = 0x331,
};

static void palmte_init(MachineState *machine)
{
    MemoryRegion *address_space_mem = get_system_memory();
    struct omap_mpu_state_s *mpu;
    int flash_size = 0x00800000;
    static uint32_t cs0val = 0xffffffff;
    static uint32_t cs1val = 0x0000e1a0;
    static uint32_t cs2val = 0x0000e1a0;
    static uint32_t cs3val = 0xe1a0e1a0;
    int rom_size, rom_loaded = 0;
    MachineClass *mc = MACHINE_GET_CLASS(machine);
    MemoryRegion *flash = g_new(MemoryRegion, 1);
    MemoryRegion *cs = g_new(MemoryRegion, 4);

    if (machine->ram_size != mc->default_ram_size) {
        char *sz = size_to_str(mc->default_ram_size);
        error_report("Invalid RAM size, should be %s", sz);
        g_free(sz);
        exit(EXIT_FAILURE);
    }

    memory_region_add_subregion(address_space_mem, OMAP_EMIFF_BASE,
                                machine->ram);

    mpu = omap310_mpu_init(machine->ram, machine->cpu_type);

    /* External Flash (EMIFS) */
    memory_region_init_rom(flash, NULL, "palmte.flash", flash_size,
                           &error_fatal);
    memory_region_add_subregion(address_space_mem, OMAP_CS0_BASE, flash);

    memory_region_init_io(&cs[0], NULL, &static_ops, &cs0val, "palmte-cs0",
                          OMAP_CS0_SIZE - flash_size);
    memory_region_add_subregion(address_space_mem, OMAP_CS0_BASE + flash_size,
                                &cs[0]);
    memory_region_init_io(&cs[1], NULL, &static_ops, &cs1val, "palmte-cs1",
                          OMAP_CS1_SIZE);
    memory_region_add_subregion(address_space_mem, OMAP_CS1_BASE, &cs[1]);
    memory_region_init_io(&cs[2], NULL, &static_ops, &cs2val, "palmte-cs2",
                          OMAP_CS2_SIZE);
    memory_region_add_subregion(address_space_mem, OMAP_CS2_BASE, &cs[2]);
    memory_region_init_io(&cs[3], NULL, &static_ops, &cs3val, "palmte-cs3",
                          OMAP_CS3_SIZE);
    memory_region_add_subregion(address_space_mem, OMAP_CS3_BASE, &cs[3]);

    palmte_microwire_setup(mpu);

    qemu_add_kbd_event_handler(palmte_button_event, mpu);

    palmte_gpio_setup(mpu);

    /* Setup initial (reset) machine state */
    if (nb_option_roms) {
        rom_size = get_image_size(option_rom[0].name);
        if (rom_size > flash_size) {
            fprintf(stderr, "%s: ROM image too big (%x > %x)\n",
                            __func__, rom_size, flash_size);
            rom_size = 0;
        }
        if (rom_size > 0) {
            rom_size = load_image_targphys(option_rom[0].name, OMAP_CS0_BASE,
                                           flash_size);
            rom_loaded = 1;
        }
        if (rom_size < 0) {
            fprintf(stderr, "%s: error loading '%s'\n",
                            __func__, option_rom[0].name);
        }
    }

    if (!rom_loaded && !machine->kernel_filename && !qtest_enabled()) {
        fprintf(stderr, "Kernel or ROM image must be specified\n");
        exit(1);
    }

    /* Load the kernel.  */
    arm_load_kernel(mpu->cpu, machine, &palmte_binfo);
}

static void palmte_machine_init(MachineClass *mc)
{
    mc->desc = "Palm Tungsten|E aka. Cheetah PDA (OMAP310)";
    mc->init = palmte_init;
    mc->ignore_memory_transaction_failures = true;
    mc->default_cpu_type = ARM_CPU_TYPE_NAME("ti925t");
    mc->default_ram_size = 0x02000000;
    mc->default_ram_id = "omap1.dram";
}

DEFINE_MACHINE("cheetah", palmte_machine_init)

static void palm_register_types(void)
{
    type_register_static(&palm_misc_gpio_info);
}

type_init(palm_register_types)
