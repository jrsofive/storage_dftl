#include "trace/trace-hw_acpi.h"
