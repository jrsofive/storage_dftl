#include "qemu/osdep.h"
#include "hw/mem/nvdimm.h"
#include "hw/hotplug.h"

void nvdimm_acpi_plug_cb(HotplugHandler *hotplug_dev, DeviceState *dev)
{
    return;
}
