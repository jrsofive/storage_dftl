#include "trace/trace-hw_i386_kvm.h"
