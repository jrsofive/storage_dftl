#include "trace/trace-hw_i386_xen.h"
