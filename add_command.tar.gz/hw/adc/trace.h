#include "trace/trace-hw_adc.h"
